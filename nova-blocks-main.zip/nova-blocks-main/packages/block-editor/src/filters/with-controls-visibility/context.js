import { createContext } from "@wordpress/element";

const ControlsVisibilityContext = createContext( 'ControlsVisibility' );

export default ControlsVisibilityContext;
